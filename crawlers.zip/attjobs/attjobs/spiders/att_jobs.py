#DAMN IT.... 
#DIFFICULTY - MOD
#########

import scrapy
from crawling.item import BebeeItem
from crawling.mapperGeoCache import MapperGeoCache
from crawling.bebeeLogger import BebeeLogger
from pprint import pprint
from datetime import datetime

from scrapy.contrib.spiders import CrawlSpider, Rule
from scrapy.http import Request
from scrapy import signals
from scrapy.xlib.pydispatch import dispatcher

from selenium import webdriver
from selenium.webdriver.common.by import By
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.action_chains import ActionChains
from selenium.webdriver.common.keys import Keys

from time import time
from time import sleep
import re
import json
from w3lib.html import remove_tags
import requests
import ConfigParser
import langid

from scrapy.spiders import Spider

#########

import scrapy
from time import time
from time import sleep
import re
import json
from w3lib.html import remove_tags
import requests
import ConfigParser
import scrapy
import os
import sys
import langid
import json
from crawling.item import BebeeItem
from crawling.mapperGeoCache import MapperGeoCache
from crawling.bebeeLogger import BebeeLogger
from pprint import pprint
from datetime import datetime

from selenium import webdriver
from scrapy.spider import BaseSpider
from scrapy.selector import HtmlXPathSelector
from scrapy.http import HtmlResponse
from selenium.webdriver.support.ui import WebDriverWait
from selenium.webdriver.support import expected_conditions as EC
from selenium.webdriver.common.by import By


class ATT_JOBS_SPIDER(BaseSpider) :
	
	name = 'ATT_JOBS'
	allowed_domains = ['connect.att.jobs']
	start_urls = [
	'http://connect.att.jobs'
	]
	
	# Override settings	
	# http://stackoverflow.com/questions/25353650/scrapy-how-to-import-the-settings-to-override-it
	def set_crawler(self, crawler):
		super(ATT_JOBS_SPIDER, self).set_crawler(crawler)

		# Getting the BEBEE CONFIGURATION PARAMETERS from .ini
		# Second level configuration file takes precedence over settings.py
		config = ConfigParser.ConfigParser()
		if config.read('./crawling/spiders/' + self.name + '.ini'):
			for name, value in config.items('DEFAULT'):
				crawler.settings.set(name.upper(), value)
		else:
			# NO .ini configuration file
			print "WARNING: no %s.ini config. using default values" % self.name
		
		# Getting the BEBEE CONFIGURATION PARAMETERS 
		self.page_index 	= crawler.settings.getint('BEBEE_SPIDER_FIRST_PAGE', 1)
		self.stop_index 	= crawler.settings.getint('BEBEE_SPIDER_LAST_PAGE', 1)
		self.max_jobs 	= crawler.settings.getint('BEBEE_SPIDER_MAX_ITEMS', 3)
		self.delay_crawl_page = crawler.settings.getint('BEBEE_SPIDER_CRAWL_DELAY_PAGE', 5)
		self.delay_crawl_job 	= crawler.settings.getint('BEBEE_SPIDER_CRAWL_DELAY_ITEM', 1)
		self.max_execution_time = crawler.settings.getint('BEBEE_SPIDER_MAX_EXECUTION_TIME', 1800)
		self.account_id 	= crawler.settings.get('BEBEE_SPIDER_ACCOUNT_ID', '0')
		self.company_id 	= crawler.settings.get('BEBEE_SPIDER_COMPANY_ID', '')

		# Logger start. This code need account_id 
		self.beBeeLogger = BebeeLogger(account_id=self.account_id, botName=self.name)
		self.beBeeLogger.init()
	
	def __init__(self):
		# signal for closing method: 
		dispatcher.connect(self.spider_closed, signals.spider_closed)
		# Selenium driver 
		self.driver = webdriver.PhantomJS()
		self.driver.set_window_size(1024,768)
		
		# Mapper for geoname_id and country_code
		self.geoCache = MapperGeoCache()

		# List of unique categories
		self.uniqueCategoriesSet = set()
		
		# Erase old categories
		fset = open('crawling/spiders/attCategoriesMissing.json', 'w')
		json.dump(list(self.uniqueCategoriesSet), fset)
		fset.close()
		# Load the dict for category mapper
		# Change this filename in each spider class
		with open('crawling/spiders/attCategoriesMap.json') as data_file:    
			self.categories = json.load(data_file)
		
		# for counting elapsed time
		self.start_time = time()
		
	def spider_closed(self):
		
		# Close selenium driver to avoid too much phantomJS running
		self.driver.close()
		
		# Saving the unique set of categories
		# Change this filename in each spider class
		fset = open('crawling/spiders/attCategoriesMissing.json', 'w')
		json.dump(list(self.uniqueCategoriesSet), fset)
		fset.close()

		# Log end
		self.beBeeLogger.end()
	

	
	def myHREF(self, htmlcode) :
		hrefs = []
		htmlcode = htmlcode.encode('ascii','ignore') #converted to string
		item = htmlcode
		htmllen = len(htmlcode)
		i=0
		while i < htmllen :
			if item[i]=='h' and item[i+1]=='r' and item[i+2]=='e' and item[i+3]=='f' and item[i+4]=='=':
				i=i+6
				url = ''
				while item[i] != '"' :
					url += item[i]
					i=i+1
				if 'javascript' not in url :
					hrefs.append(url)
			i=i+1
		#~ print 'printing URLSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSSS'
		#~ for href in hrefs :
			#~ print '-> ' + href
		return hrefs
		
	def hrfenjobid(self, htmlcode) :
		htmlcode = htmlcode.encode('ascii','ignore') #converted to string
		item = htmlcode
		htmllen = len(htmlcode)
		i=100
		url = ''
		jobid = ''
		while i < htmllen :
			if item[i]=='h' and item[i+1]=='t' and item[i+2]=='t' and item[i+3]=='p' :
				if (item[i+4]=='s' and item[i+5]==':') or item[i+4]==':' :
					while item[i] != '\'' : 
						url += item[i]
						i=i+1
					while True :
						if item[i]=='o' and item[i+1]=='b' and item[i+2]=='i' and item[i+3]=='d' and item[i+4]=='=' :
							i=i+5
							while item[i] != '&' :
								jobid += item[i]
								i=i+1
							break
						i=i+1
					break
			i=i+1
		return jobid, url
			
	def parse(self, response) :
		
		# storages for data
		links = []
		titles = []
		locations = []
		categories = []
		dates = []
		offerids = []
		descriptions = []
		langs = []
		
		
		fakejoblink = []		
		reload(sys)
		sys.setdefaultencoding("utf-8")
		#browser = webdriver.PhantomJS()
		#browser.set_window_size(1024,768)
		#raw_input('Release the SPIDER')
		
		jobCateogary = response.xpath('//select[@id="ddlASCategory"]//text()').extract()
		temporaryList = []
		jobCateogaryList = []
		for jc in jobCateogary :
			jc = jc.encode('ascii','ignore')
			if(len(jc) > 2) :
				temporaryList.append(jc)
		for item in temporaryList :
			item = item.replace('\\','_backslash_')
			jobCateogaryList.append(item.replace(' ','%20'))
		#i=0
		for jobLink in jobCateogaryList :
			#if i==0:
			#	break
			#i=i+1
			new_url = 'http://connect.att.jobs/search/advanced-search/ASCategory/'+jobLink+'/ASPostedDate/-1/ASCountry/-1/ASState/-1/ASCity/-1/ASLocation/-1/ASCompanyName/-1/ASCustom1/-1/ASCustom2/-1/ASCustom3/-1/ASCustom4/-1/ASCustom5/-1/ASIsRadius/false/ASCityStateZipcode/-1/ASDistance/-1/ASLatitude/-1/ASLongitude/-1/ASDistanceType/-1'
			browser.get(new_url)
			new_response = browser.page_source
			#new_response = HtmlResponse(url = new_url, body = string_response)
			#print type(new_response)
			#hxs = HtmlXPathSelector(new_response)
			#raw_table = hxs.xpath('//table').extract()
			#raw_table = browser.find_element_by_xpath('//div[@class="content-box bg-gradient-white"]').text #LOL THIS WORKED
			#rawTable = new_response.xpath('//table').extract()
			sleep(5)
			WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//div[@id="conteinerForSearchResults"]')))
			whole_div = browser.find_element_by_xpath('//div[@id="conteinerForSearchResults"]')#//table[@class="tableSearchResults"]') #kuch toh hua print
			div_str = whole_div.get_attribute('outerHTML')
			fakejoblink=(self.myHREF(div_str))
			while "Next page" in div_str :
				#press and extract new jobs. 
				#print 'getting inside by clicking next lets seee.....................'
				WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="search_result_next_page_link"]')))
				browser.find_element_by_xpath('//*[@id="search_result_next_page_link"]').click()#//div[@id="conteinerForSearchResults"]//table[@class="tableSearchResults"]//a[@class="numberedNext"]').click() #kuch toh hua print
				sleep(5)
				new_response = browser.page_source
				WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//div[@id="conteinerForSearchResults"]')))
				whole_div = browser.find_element_by_xpath('//div[@id="conteinerForSearchResults"]')
				div_str = whole_div.get_attribute('outerHTML')
				fffakejoblink=(self.myHREF(div_str))
				for item in fffakejoblink :
					fakejoblink.append(item)
				
			# DONE EXTRACTING JOB LINK PAGES.
		
		# VISIT ACTUAL JOB LINK CONTAINING PAGE.
		##JUST FOR TESTING PURPOSE#fakejoblink = ['http://connect.att.jobs/sk/bratislava/accountant/jobid8367004-sr.-associate-billing-accounting-jobs']
		for joblinkpage in fakejoblink :
			browser.get(joblinkpage)
			new_response = browser.page_source
			links.append(joblinkpage)
			#title.append(browser.)
			#print 'title --> ',browser.find_element_by_xpath('//*[@id="job-title"]').text
			WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//*[@id="job-title"]')))
			titles.append(browser.find_element_by_xpath('//*[@id="job-title"]').text)
			#job_link, jobID
			#print 'jobid, link --> ',self.hrfenjobid((browser.find_element_by_xpath('//div[@id="job-desc-top"]')).get_attribute('outerHTML'))
			WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//div[@id="job-desc-top"]')))
			jid,ln = self.hrfenjobid((browser.find_element_by_xpath('//div[@id="job-desc-top"]')).get_attribute('outerHTML'))
			offerids.append(jid)
			links.append(ln)
			#location
			#print 'location --> ',((browser.find_element_by_xpath('//div[@id="job-desc"]//p').text).encode('ascii','ignore')).split(': ')[1]
			WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//div[@id="job-desc"]//p')))
			locations.append(((browser.find_element_by_xpath('//div[@id="job-desc"]//p').text).encode('ascii','ignore')).split(': ')[1])
			#description
			#print 'description --> ',(((browser.find_element_by_xpath('//div[@id="job-desc"]').text).encode('ascii','ignore')).split('Job Description:')[1]).split('Apply')[0]
			WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//div[@id="job-desc"]')))
			descriptions.append((((browser.find_element_by_xpath('//div[@id="job-desc"]').text).encode('ascii','ignore')).split('Job Description:')[1]).split('Apply')[0])
			#cateogary
			WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//div[@class="content-box bg-gradient-blue"]')))
			categories.append(((((browser.find_element_by_xpath('//div[@class="content-box bg-gradient-blue"]')).text).encode('ascii','ignore')).split('About ')[1]).split(' Jobs')[0])
			#print 'URL ->>>>>>>>>>> ',((((browser.find_element_by_xpath('//div[@class="content-box bg-gradient-blue"]')).text).encode('ascii','ignore')).split('About ')[1]).split(' Jobs')[0]
			#language
			WebDriverWait(browser, 10).until(EC.presence_of_element_located((By.XPATH, '//div[@id="job-desc"]')))
			language = langid.classify(browser.find_element_by_xpath('//div[@id="job-desc"]').text)[0]
			if (language == 'en'):
				langs.append('en-US')
			elif (language == 'es'):
				langs.append('en-ES')
			elif (language == 'pt'):
				langs.append('pt-BR')
			else:
				langs.append(language)
		
		for i in range(len(titles)):
			error_location = False
			error_category = False
			
			# Object to create XML
			item = BebeeItem()
			item['title'] = titles[i]
			item['offer_id'] = offerids[i]
			item['url'] = links[i]
			#item['date'] = dates[i]
			item['account_id'] = str(self.account_id)
			item['company_id'] = str(self.company_id)
			item['location_name'] = locations[i]
			item['category_name'] = categories[i]
			item['description'] = descriptions[i]
			language = langid.classify(item['description'])[0]
			if (language == 'en'):
				item['lang_code']= 'en-US'
			elif (language == 'es'):
				item['lang_code']= 'es-ES'
			elif (language == 'pt'):
				item['lang_code'] = 'pt-BR'
			else:
				item['lang_code'] = language
			
			#GEONAME MANAGEMENT
			try:
				item['geoname_id'] = self.geoCache.getGeonameId(locations[i])
				item['country_code'] = self.geoCache.getCountryCode(locations[i])
			except:
				error_message = "%s location not found in GeoName" % str(locations[i])
				print error_message
				error_location = True
				self.beBeeLogger.failure(item['offer_id'], error_message)
			
			category_id = self.categoryMapper(item['category_name'])
			if category_id:
				item['category_id'] = category_id
			else:
				error_message = "category not found: %s" % str(item['category_name'])
				print error_message
				error_category = True
				self.beBeeLogger.failure(item['offer_id'], error_message)
			
			#Count success jobs
			if not (error_location or error_category):
				self.beBeeLogger.success(item['offer_id'])
			
			#Print progress
			if ((i % 100)==0):
				print "-------------------"
				print "Jobs crawled: " + str(i)
				self.beBeeLogger.progress()

			yield item
	
		# category_id Mapper function
	def categoryMapper(self, category_name):
		if category_name in self.categories:
			category_id = self.categories[category_name]
			return category_id
		else:
			# saving the unique set of categories
			self.uniqueCategoriesSet.add(category_name)
			fset = open('uberCategoriesMissing.json', 'w')
			json.dump(list(self.uniqueCategoriesSet), fset)
			fset.close()
			return None


